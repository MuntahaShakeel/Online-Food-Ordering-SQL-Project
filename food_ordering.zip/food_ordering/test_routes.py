import pytest
from flask.testing import FlaskClient
from app import app  # or from app import create_app if you used a factory

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_home(client: FlaskClient):
    response = client.get('/')
    assert response.status_code == 200
    assert b'Welcome to the Online Food Ordering System' in response.data

def test_register_get(client: FlaskClient):
    response = client.get('/register')
    assert response.status_code == 200

def test_login_get(client: FlaskClient):
    response = client.get('/login')
    assert response.status_code == 200

def test_menu(client: FlaskClient):
    response = client.get('/menu')
    assert response.status_code in (200, 500)

def test_admin_dashboard(client: FlaskClient):
    response = client.get('/admin/dashboard')
    assert response.status_code in (200, 403)

def test_customer_dashboard(client: FlaskClient):
    response = client.get('/customer/dashboard')
    assert response.status_code in (200, 403)