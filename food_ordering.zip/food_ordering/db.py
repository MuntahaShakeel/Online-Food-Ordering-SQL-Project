import pyodbc

def get_db_connection():
    conn = pyodbc.connect(
        'Driver={ODBC Driver 18 for SQL Server};'
        'Server=DESKTOP-RHCK80T;'  # Your server name from SSMS
        'Database=online_food_delivery;'  # Your actual DB name
        'Trusted_Connection=yes;'  # Since you're using Windows Authentication
        'TrustServerCertificate=yes;'  # To skip SSL warning locally
        'Encrypt=no;'  # Disable if testing locally
    )
    return conn

from db import get_db_connection

conn = get_db_connection()
cursor = conn.cursor()

cursor.execute("SELECT name FROM sys.databases;")
for row in cursor.fetchall():
    print(row)

conn.close()