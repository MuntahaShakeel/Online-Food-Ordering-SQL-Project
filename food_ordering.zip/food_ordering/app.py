from flask import Flask, request, render_template, redirect, session, flash
import re
from db import get_db_connection
from werkzeug.utils import secure_filename
import os

app = Flask(__name__,static_folder="statics",static_url_path="/statics",template_folder="templates")
# app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024
app.config['UPLOAD_EXTENSIONS'] = [ '.png']
app.config['UPLOAD_PATH'] = 'statics'
# ================= Home Redirect =================
@app.route('/')
def home():
    if 'user_id' in session:
        return redirect(f"/{session['role']}/dashboard")
    return redirect('/login')

# ================= Register =================
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        fullname = request.form['fullname']
        email = request.form['email']
        password = request.form['password']
        role = 'customer'

        if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email):
            flash("❌ Invalid email format.", "danger")
            return redirect('/register')
        if len(password) < 6:
            flash("❌ Password must be at least 6 characters.", "danger")
            return redirect('/register')

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("EXEC RegisterUser ?, ?, ?, ?", fullname, email, password, role)
            conn.commit()
            conn.close()
            flash("✅ Registered successfully!", "success")
            return redirect('/login')
        except Exception as e:
            flash(f"❌ Error: {str(e)}", "danger")
            return redirect('/register')

    return render_template("register.html")

# ================= Login =================
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("EXEC LoginUser ?", email)
            user = cursor.fetchone()
            conn.close()

            if not user:
                flash("❌ User not found. Please register.", "danger")
                return redirect('/register')
            if user.PasswordHash != password:
                flash("❌ Incorrect password.", "danger")
                return redirect('/login')

            session['user_id'] = user.UserID
            session['role'] = user.Role
            session['cart'] = []
            flash("✅ Login successful!", "success")
            return redirect(f"/{user.Role}/dashboard")

        except Exception as e:
            flash(f"❌ Error: {str(e)}", "danger")
            return redirect('/login')

    return render_template("login.html")

# ================= Logout =================
@app.route('/logout')
def logout():
    session.clear()
    flash("✅ Logged out successfully.", "success")
    return redirect('/login')

# ================= Menu =================
@app.route('/menu', methods=['GET', 'POST'])
def menu():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("EXEC GetAvailableMenuItems")
        items = cursor.fetchall()
        conn.close()

        if request.method == 'POST' and session.get('role') == 'customer':
            cart = []
            for item in items:
                if str(item.ItemID) in request.form.getlist('selected_items'):
                    quantity = int(request.form.get(f'quantity_{item.ItemID}', 1))
                    cart.append({
                        'item_id': item.ItemID,
                        'quantity': quantity,
                        'price': float(item.Price)
                    })
            session['cart'] = cart
            return redirect('/place_order')

        cart_count = sum(item['quantity'] for item in session.get('cart', []))
        print(f"Cart count: {cart_count}")  # Debugging line to check cart count
        print(f"Cart items: {session}")  # Debugging line to check cart items
        return render_template("menu.html", items=items, cart_count=cart_count)

    except Exception as e:
        flash(f"❌ Error loading menu: {str(e)}", "danger")
        return redirect('/')
    


@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    if 'user_id' not in session or session.get('role') != 'customer':
        return redirect('/login')

    item_id = int(request.form['item_id'])
    quantity = int(request.form['quantity'])
    price = float(request.form['price'])
    name = request.form['name']

    # Initialize cart if not exists
    if 'cart' not in session:
        session['cart'] = []

    cart = session['cart']

    # Check if item already exists, then update quantity
    for item in cart:
        if item['item_id'] == item_id:
            item['quantity'] += quantity
            break
    else:
        cart.append({'item_id': item_id, 'quantity': quantity, 'price': price, 'name': name})

    session['cart'] = cart  # Update the session cart
    flash("🛒 Item added to cart!", "success")
    return redirect('/menu')


@app.route('/update_cart', methods=['POST'])
def update_cart():
    if 'user_id' not in session or session.get('role') != 'customer':
        return redirect('/login')

    cart = session.get('cart', [])

    updated_cart = []
    for item in cart:
        item_id = item['item_id']
        quantity_input = request.form.get(f'quantity_{item_id}')
        try:
            quantity = int(quantity_input)
            if quantity < 1:
                continue  # Skip invalid quantities
        except (ValueError, TypeError):
            quantity = item['quantity']

        # Handle removal
        if str(item_id) == request.form.get('remove_item'):
            continue  # Skip this item (i.e., delete it)

        updated_cart.append({
            'item_id': item_id,
            'price': item['price'],
            'quantity': quantity,
            'name': item.get('name', f"Item {item_id}")  # Optional: Replace with item name lookup if needed
        })

    session['cart'] = updated_cart
    flash("🛠️ Cart updated successfully!", "info")
    return redirect('/my_orders')

# ================= Place Order =================

@app.route('/delivery', methods=['GET', 'POST'])
def delivery():
    if 'user_id' not in session or session.get('role') != 'customer':
        return redirect('/login')

    cart = session.get('cart', [])
    if not cart:
        flash("❌ No items in cart.", "danger")
        return redirect('/menu')

    if request.method == 'POST':
        address = request.form['address']

        try:
            conn = get_db_connection()
            cursor = conn.cursor()

            total = sum(item['price'] * item['quantity'] for item in cart)
            # Step 1: Place order
            # cursor.execute("EXEC PlaceNewOrder ?, ?", session['user_id'], total)
            # cursor.execute("SELECT SCOPE_IDENTITY()")
            # order_id = cursor.fetchone()[0]
            # Declare the output parameter
            cursor.execute("EXEC PlaceNewOrder ?, ?", session['user_id'], total)
            order_id = cursor.fetchone()[0]

            # Step 2: Add each item
            for item in cart:
                cursor.execute("EXEC AddOrderItem ?, ?, ?, ?", order_id, item['item_id'], item['quantity'], item['price'])

            # Step 3: Add delivery details
            cursor.execute("EXEC UpdateDeliveryAddress ?, ?", order_id, address)

            conn.commit()
            conn.close()

            session['cart'] = []
            flash("✅ Order placed and delivery details saved!", "success")
            return redirect('/my_orders?success=true')

        except Exception as e:
            flash(f"❌ Failed to place order: {str(e)}", "danger")
            return redirect('/menu')

    return render_template("delivery.html")

@app.route('/place_order')
def place_order():
    if 'user_id' not in session or session.get('role') != 'customer':
        return redirect('/login')

    cart = session.get('cart', [])
    if not cart:
        flash("❌ No items in cart.", "danger")
        return redirect('/menu')

    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        total = sum(item['price'] * item['quantity'] for item in cart)
        cursor.execute("EXEC PlaceNewOrder ?, ?", session['user_id'], total)
        cursor.execute("SELECT SCOPE_IDENTITY()")
        order_id = cursor.fetchone()[0]

        for item in cart:
            cursor.execute("EXEC AddOrderItem ?, ?, ?, ?", order_id, item['item_id'], item['quantity'], item['price'])

        conn.commit()
        conn.close()

        session['cart'] = []
        flash("✅ Order placed successfully!", "success")
        return redirect('/my_orders')

    except Exception as e:
        flash(f"❌ Error placing order: {str(e)}", "danger")
        return redirect('/menu')

# ================= My Orders =================
@app.route('/my_orders')
def my_orders():
    if 'user_id' not in session:
        return redirect('/login')

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("EXEC GetUserOrders ?", session['user_id'])
        orders = cursor.fetchall()
        conn.close()

        # Prepare current cart summary
        cart = session.get('cart', [])
        cart_items = []
        total = 0

        for item in cart:
            subtotal = item['price'] * item['quantity']
            total += subtotal
            cart_items.append({
                'item_id': item['item_id'],
                'quantity': item['quantity'],
                'price': item['price'],
                'subtotal': subtotal,
                'name': f"Item {item['name']}"  # (Optional: Replace with item name lookup if needed)
            })

        return render_template("my_orders.html", orders=orders, cart_items=cart_items, total=round(total, 2))

    except Exception as e:
        flash(f"❌ Error fetching orders: {str(e)}", "danger")
        return redirect('/menu')
    
@app.route('/orders')
def orders():
    if 'user_id' not in session:
        return redirect('/login')

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("EXEC GetUserOrders ?", session['user_id'])
        orders = cursor.fetchall()
        conn.close()

        # Prepare current cart summary
        cart = session.get('cart', [])
        cart_items = []
        total = 0

        for item in cart:
            subtotal = item['price'] * item['quantity']
            total += subtotal
            cart_items.append({
                'item_id': item['item_id'],
                'quantity': item['quantity'],
                'price': item['price'],
                'subtotal': subtotal,
                'name': f"Item {item['name']}"  # (Optional: Replace with item name lookup if needed)
            })

        return render_template("order_list.html", orders=orders, cart_items=cart_items, total=round(total, 2))

    except Exception as e:
        flash(f"❌ Error fetching orders: {str(e)}", "danger")
        return redirect('/menu')

# ================= Admin Dashboard =================
@app.route('/admin/dashboard')
def admin_dashboard():
    if session.get('role') != 'admin':
        return "❌ Unauthorized"
    return render_template("admin_dashboard.html")

# ================= Customer Dashboard =================
@app.route('/customer/dashboard')
def customer_dashboard():
    if session.get('role') != 'customer':
        return "❌ Unauthorized"
    return render_template("customer_dashboard.html")

# ================= Admin View All Orders =================
@app.route('/admin/orders')
def admin_orders():
    if session.get('role') != 'admin':
        return "❌ Unauthorized"
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("EXEC GetAllOrders")
        orders = cursor.fetchall()
        conn.close()
        return render_template("admin_orders.html", orders=orders)
    except Exception as e:
        flash(f"❌ Error loading orders: {str(e)}", "danger")
        return redirect('/admin/dashboard')

# ================= Admin Edit Menu Item =================
@app.route('/edit_menu_item/<int:item_id>', methods=['GET', 'POST'])
def edit_menu_item(item_id):
    if session.get('role') != 'admin':
        return "❌ Unauthorized"

    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        price = request.form['price']
        category = request.form['category']
        is_available = 1 if request.form.get('is_available') else 0

        try:
            cursor.execute("EXEC UpdateMenuItem ?, ?, ?, ?, ?, ?", 
                           item_id, name, description, price, category, is_available)
            conn.commit()
            conn.close()
            flash("✅ Menu item updated.", "success")
            return redirect('/menu')
        except Exception as e:
            flash(f"❌ Error: {str(e)}", "danger")
            return redirect(f'/edit_menu_item/{item_id}')

    cursor.execute("SELECT * FROM MenuItems WHERE ItemID = ?", item_id)
    item = cursor.fetchone()
    conn.close()

    return render_template("edit_menu_item.html", item=item)

# ================= Admin Add Menu Item =================
@app.route('/add_menu_item', methods=['GET', 'POST'])
def add_menu_item():
    if session.get('role') != 'admin':
        return "❌ Unauthorized"

    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        price = request.form['price']
        category = request.form['category']
        is_available = 1 if request.form.get('is_available') else 0
        image = request.files.get('image')
        print(request)

        # Check image validity
        if not image or image.filename == '':
            flash("❌ Please upload a .png image for the menu item.", "danger")
            return redirect('/add_menu_item')
        
        filename = secure_filename(image.filename)
        file_ext = os.path.splitext(filename)[1].lower()

        if file_ext not in app.config['UPLOAD_EXTENSIONS']:
            flash("❌ Invalid image format. Only .png allowed.", "danger")
            return redirect('/add_menu_item')

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("EXEC AddMenuItem ?, ?, ?, ?, ?", name, description, price, category, is_available)
            # Get the newly inserted item ID
            # cursor.execute("SELECT SCOPE_IDENTITY()")
            item_id = cursor.fetchone()[0]
            print(f"New item ID: {item_id}")  # Debugging line to check new item ID

            conn.commit()
            conn.close()
            # Save the uploaded image as itemid.png
            image_path = os.path.join(app.config['UPLOAD_PATH'], f"{item_id}.png")
            image.save(image_path)
            flash("✅ Menu item added.", "success")
            return redirect('/menu')
        except Exception as e:
            flash(f"❌ Error: {str(e)}", "danger")
            return redirect('/add_menu_item')

    return render_template("edit_menu_item.html", item=None)

# ================= Admin Delete Menu Item =================
@app.route('/delete_menu_item/<int:item_id>', methods=['GET'])
def delete_menu_item(item_id):
    if session.get('role') != 'admin':
        return "❌ Unauthorized"

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("EXEC DeleteMenuItem ?", item_id)
        conn.commit()
        conn.close()
        flash("🗑️ Menu item deleted.", "success")
    except Exception as e:
        flash(f"❌ Error deleting item: {str(e)}", "danger")

    return redirect('/menu')

if __name__ == '__main__':
    app.run(debug=True)